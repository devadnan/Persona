<?php
class User_model extends CI_Model {

        public $first_name;
        public $last_name;
        public $email;
		public $company;
		public $phone;
		public $password;
		public $industry;
		public $address;
		public $created_at;
		public $updated_at;
		public $social_signup;
		public $social_signup_source;
		public $social_signup_id;
		

        public function __construct()
        {
			// Call the CI_Model constructor
			parent::__construct();
        }
		
        public function add_user()
        {
                $this->first_name    			= $_POST['first_name']; 
                $this->last_name  				= $_POST['last_name'];
                $this->email     				= $_POST['email'];
				$this->company    				= $_POST['company'];
                $this->phone  					= '';
                $this->password    				= md5( $_POST['password'] );
                $this->industry    				= $_POST['industry_sector'];
				$this->address     				= '';
				$this->social_signup  			= 'no';
                $this->social_signup_source 	= '';
				$this->social_signup_id     	= '';
				$this->created_at     			= time();
				$this->updated_at     			= time();

                $this->db->insert('user', $this);
        }
		
        public function login_user()
        {
                $email     				= $_POST['email'];
				$password    			= $_POST['password'];
                //die;
                $this->db->select('*');
				$this->db->from('user');
				$this->db->where('email', $email);
				$this->db->where('password', md5( $password ) );
				$this->db->limit(1);
				$query = $this->db->get();
				if( $query->num_rows() == 1 ){
					//$this->session->
					
					$user_object	= $query->result();
					$user_id		= $user_object[0]->id;
					$email			= $user_object[0]->email;
					$first_name		= $user_object[0]->first_name;
					$is_social		= $user_object[0]->social_signup;
					
					$this->session->set_userdata('login_key', mt_rand() ) ;
					$this->session->set_userdata('first_name', $first_name ) ;
					$this->session->set_userdata('email', $email ) ;
					$this->session->set_userdata('user_id', $user_id ) ;
					
					return $user_object;
				}else{
					return false;
				}
        }
		
		public function check_email_existing_user()
		{	
			$result = $this->db->select('id')->from('user')->where('email', $_POST['email'])->get()->row_array();
			
			if ( count ( $result ) > 0 ) {
				return true;	
			}
			else {
				return false;
			}
			
		}
		
		public function send_reset_password_email()
		{	
			$email	= $_POST['email'];
			$result = $this->db->select('id')->from('user')->where('email', $email )->get();
			
			if ( $result->num_rows() > 0 ) {
				$user_object	= $result->result();
				$user_id		= $user_object[0]->id;
				
				$random_key = $this->generateRandomString();
				
				$data = array(
					'user_id'	=> $user_id,
					'reset_key' => $random_key
				);

                $this->db->insert( 'reset_password', $data );
				
				if( $this->db->affected_rows() == 1 ){
					$this->send_mail( $user_id, $random_key );
				}
				
			}
			else {
				return false;
			}
			
		}
		
		public function update_password( $user_id, $password )
		{	
			
			$args	= array( 'password' => md5( $password ) );
			$result = $this->db->where( 'id', $user_id );
			$update = $this->db->update( 'user', $args );
			
			if ( $update ) {
				$this->db->where( 'user_id', $user_id );
				$this->db->delete('reset_password');
				return true;
			}
			else {
				return false;
			}
			
		}
		
		function generateRandomString( $length = 30 ) {
			$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$charactersLength = strlen($characters);
			$randomString = '';
			for ($i = 0; $i < $length; $i++) {
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
			return $randomString;
		}
		
		public function send_mail( $user_id, $random_key ){
			
			$CI =& get_instance();
			$CI->load->library('email');
			
			$message	= 'Click the link to update your password: ';
			$message	.= base_url().'/user/change_password/'.$user_id.'/'.$random_key;
			echo $message;die;
			$config = Array(
				'protocol'	=> 'smtp',
				'smtp_host'	=> 'ssl://smtp.googlemail.com',
				'smtp_port'	=> 465,
				'smtp_user'	=> 'xxx@gmail.com', // change it to yours
				'smtp_pass'	=> 'dev.adnan@sigmasqr.com', // change it to yours
				'mailtype'	=> 'html',
				'charset'	=> 'utf-8',
				'wordwrap'	=> TRUE
			);
			$CI->email->initialize($config);
			
			$CI->email->set_newline("\r\n");
			$CI->email->from('xxx@gmail.com'); // change it to yours
			$CI->email->to('dev.adnan@sigmasqr.com');// change it to yours
			$CI->email->subject('Reset your password');
			$CI->email->message($message);
			if($CI->email->send())
			{
				echo 'Email sent.';
			}
			else
			{
				show_error($CI->email->print_debugger());
			}
		}
		
		public function check_reset_password_link( $user_id, $random_key ){
			$this->db->select('*');
			$this->db->from('reset_password');
			$this->db->where( 'user_id', $user_id );
			$this->db->where( 'reset_key', $random_key );
			$this->db->limit(1);
			
			$query = $this->db->get();
			
			if( $query->num_rows() == 1 ){
				return true;
			}else{
				return false;
			}
			
		}

}