<div class="col-md-5 col-md-offset-1">
		<h2>
			Welcome to dashboard! <strong><?php echo $this->session->userdata('first_name'); ?></strong>
		</h2>
    </div>