<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>




    <div class="col-sm-5 col-xs-12">
		<h2>
			Sign up, it’s <strong>free</strong>
		</h2>
		<p>
			The talent of success is nothing more than doing 
			what you can do, well.
		</p>
		<br/>

		<button class="btn btn-block btn-info col-md-8" type="button">
			<span class="pull-left icon-facebook" style="font-style: italic"></span> <span class="bold">Login with Facebook</span>
		</button>
		<button class="btn btn-block btn-success col-md-8" type="button">
			<span class="pull-left icon-twitter" style="font-style: italic"></span> <span class="bold">Login with Twitter</span>
		</button>
		<button class="btn btn-block btn-danger col-md-8" type="button">
			<span class="pull-left icon-twitter" style="font-style: italic"></span> <span class="bold">Login with Gmail</span>
		</button>
    </div>
    <div class="col-sm-7 col-xs-12">
		<br/>
		<?php
			$hidden			= array();
			$attributes		= array( 'class' => 'signup-form validate', 'id' => 'signup-form' );
			$label_attrs	= array( 'class' => 'form-label', );
			echo form_open( 'user/process-signup', $attributes, $hidden );
		?>
			<div class="row">
				<?php
					if( $this->session->flashdata( 'signup_error' ) ){
						echo "<p style='color:red; padding: 0px 0 0 15px;'>". $this->session->flashdata( 'signup_error' ) ."</p>";
					}
				?>
				<div class="form-group col-sm-6 col-xs-12">
					<?php
						echo form_label( 'First name', 'first_name', $label_attrs );
						echo form_input( array( 'type' => 'text', 'name' => 'first_name', 'id' => 'first_name', 'required' => 'required', 
						'class' => 'form-control', ) );
					?>
				</div>
				<div class="form-group col-sm-6 col-xs-12">
					<label class="form-label">Last name</label>
					<?php
						echo form_label( 'Last name', 'last_name', $label_attrs );
						echo form_input( array( 'type' => 'text', 'name' => 'last_name', 'id' => 'last_name', 'required' => 'required', 
						'class' => 'form-control', ) );
					?>
				</div>
				<div class="form-group col-xs-12">
					<?php
						echo form_label( 'Company name', 'company', $label_attrs );
						echo form_input( array('type' => 'text', 'name'  => 'company', 'id' => 'company', 'class' => 'form-control', ) );
					?>
				</div>
			</div>
        
			<div class="row">
				<div class="form-group col-xs-12">
					<?php
						echo form_label( 'Email address', 'email', $label_attrs );
						echo form_input( array( 'type' => 'email', 'name' => 'email', 'id' => 'email', 'required' => 'required', 'class' => 'form-control', ) );
					?>
				</div>
			</div>
			<div class="row">
				<div class="form-group col-sm-6 col-xs-12">
					<?php
						echo form_label( 'Password', 'password', $label_attrs );
						echo form_input( array('type' => 'password', 'name' => 'password', 'id' => 'password', 'required' => 'required', 
						'class' => 'form-control', ) );
					?>
				</div>
				<div class="form-group col-sm-6 col-xs-12">
					<?php
						echo form_label( 'Confirm Password', 'confirm_password', $label_attrs );
						echo form_input( array('type' => 'password', 'name' => 'confirm_password', 'id' => 'confirm_password', 'required' => 'required', 
						'class' => 'form-control', ) );
					?>
				</div>
			</div>
			<div class="row">
				<div class="form-group col-xs-12">
					<?php
						echo form_label( 'Industry/Sector', 'industry_sector', $label_attrs );
						echo form_input( array('type' => 'password', 'name' => 'industry_sector', 'id' => 'industry_sector', 'required' => 'required', 
						'class' => 'form-control', 'placeholder' => '(eg. Government, Software, Design, Marketing,,,etc)' ) );
					?>
				</div>
			</div>
			<div class="row">
				<div class="control-group col-xs-12">
					<div class="checkbox checkbox check-success">
						&nbsp;&nbsp; 
						<?php
							echo form_input( array( 'type' => 'checkbox', 'name' => 'checkbox1', 'id' => 'checkbox1', 'required' => 'required', 
							'value' => '1', 'class' => 'form-control', ) );
							echo form_label( 'I Here by agree on the <a href="#">Term and condition.</a>', 'checkbox1', $label_attrs );
						?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12">
					<?php echo form_submit( array( 'id' => 'submit', 'value' => 'Signup', 'class' => 'btn btn-primary btn-cons pull-right' ) ); ?>
				</div>
			</div>
		<?php echo form_close(); ?>
    </div>