<div class="col-xs-12 reset-psw-container">
      <h2>
       Reset <strong>Password</strong>
      </h2>
      <p>
        Enter your email address that you used to register. We'll send you an email with your username and a link to reset your password..
      </p> 
    </div>
    <div class="col-xs-12 reset-psw-container">
      <br>
	  <?php
			$hidden			= array();
			$attributes		= array( 'class' => 'reset_password_form validate', 'id' => 'reset_password_form' );
			$label_attrs	= array( 'class' => 'form-label', );
			echo form_open( 'user/send_reset_password_email', $attributes, $hidden );
		?>
        <div class="row">
			<div class="form-group col-xs-12">

				<?php
					echo form_label( 'Email Address', 'email', $label_attrs );
					echo form_input( array( 'type' => 'email', 'name' => 'email', 'id' => 'email', 'required' => 'required', 
					'class' => 'form-control' ) );
				?>

			</div>
        </div>
        
        
        <div class="row">
			<div class="col-xs-12">
				<?php echo form_submit( array( 'id' => 'reset_pswd', 'value' => 'Send Request', 
				'class' => 'btn btn-primary btn-cons pull-right' ) ); ?>
			</div>
        </div>
      </form>
    </div>