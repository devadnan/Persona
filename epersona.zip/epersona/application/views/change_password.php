<div class="col-xs-12 reset-psw-container">
      <h2>
       Reset <strong>Password</strong>
      </h2>
      <p>
        Enter your email address that you used to register. We'll send you an email with your username and a link to reset your password..
      </p> 
    </div>
    <div class="col-xs-12 reset-psw-container">
      <br>
	  <?php
			$hidden			= array();
			$attributes		= array( 'class' => 'reset_password_form validate', 'id' => 'reset_password_form' );
			$label_attrs	= array( 'class' => 'form-label', );
			echo form_open( 'user/update_password', $attributes, $hidden );
		?>
        <div class="row">
			<?php
				if( $this->session->flashdata( 'reset_password_error' ) ){
					echo "<p style='color:red; padding: 0px 0 0 15px;'>". $this->session->flashdata( 'reset_password_error' ) ."</p>";
				}
			?>
			<div class="form-group col-xs-12">

				<?php
					echo form_label( 'New Password', 'password', $label_attrs );
					echo form_input( array( 'type' => 'hidden', 'name' => 'user_id', 'value' => $user_id ) );
					echo form_input( array( 'type' => 'hidden', 'name' => 'reset_key', 'value' => $reset_key ) );
					echo form_input( array( 'type' => 'password', 'name' => 'password', 'id' => 'password', 'required' => 'required', 
					'class' => 'form-control' ) );
				?>

			</div>
			<div class="form-group col-xs-12">

				<?php
					echo form_label( 'Confirm New Password', 'confirm_password', $label_attrs );
					echo form_input( array( 'type' => 'password', 'name' => 'confirm_password', 'id' => 'confirm_password', 
					'required' => 'required', 'class' => 'form-control' ) );
				?>

			</div>
        </div>
        
        
        <div class="row">
			<div class="col-xs-12">
				<?php echo form_submit( array( 'id' => 'reset_pswd', 'value' => 'Send Request', 
				'class' => 'btn btn-primary btn-cons pull-right' ) ); ?>
			</div>
        </div>
      </form>
    </div>