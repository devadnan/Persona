<div class="col-md-5 col-md-offset-1">
		<h2>
			Login your <strong>Account</strong>
		</h2>
		<p>
			Use Facebook, Twitter or your email to sign in.<br>
			<a href="<?php echo base_url('/user/signup'); ?>">Sign up Now!</a> for a webarch account,It's free and always will be..
		</p>
		<br/>
		<button class="btn btn-block btn-info col-md-8" type="button">
			<span class="pull-left icon-facebook" style="font-style: italic"></span> <span class="bold">Login with Facebook</span>
		</button>
		<button class="btn btn-block btn-success col-md-8" type="button">
			<span class="pull-left icon-twitter" style="font-style: italic"></span> <span class="bold">Login with Twitter</span>
		</button>
		<button class="btn btn-block btn-danger col-md-8" type="button">
			<span class="pull-left icon-twitter" style="font-style: italic"></span> <span class="bold">Login with Gmail</span>
		</button>
    </div>
    <div class="col-md-5">
      <br>
	  
		<?php
			$hidden			= array();
			$attributes		= array( 'class' => 'login-form validate', 'id' => 'login-form' );
			$label_attrs	= array( 'class' => 'form-label', );
			echo form_open( 'user/login_process', $attributes, $hidden );
		?>
        <div class="row">
			<div class="form-group col-md-10">
				<?php
					echo form_label( 'Username', 'email', $label_attrs );
					echo form_input( array( 'type' => 'email', 'name' => 'email', 'id' => 'email', 'required' => 'required', 
					'class' => 'form-control', 'placeholder', 'Your email address' ) );
				?>
			</div>
        </div>
        <div class="row">
			<div class="form-group col-md-10">
				<?php
					echo form_label( 'Password', 'email', $label_attrs );
					echo "<span class='help'></span>";
					echo form_input( array( 'type' => 'password', 'name' => 'password', 'id' => 'password', 'required' => 'required', 
					'class' => 'form-control' ) );
				?>
			</div>
        </div>
        <div class="row">
			<div class="control-group col-md-10">
				<div class="checkbox checkbox check-success">
					<?php
						echo form_input( array( 'type' => 'checkbox', 'name' => 'checkbox1', 'id' => 'checkbox1', 'required' => 'required', 
						'value' => '1', 'class' => 'form-control', ) ); 
						echo form_label( 'I Here by agree on the <a href="#">Term and condition.</a>', 'checkbox1', $label_attrs );
					?>

				</div>
			</div>
        </div>
        <div class="row">
		<div class="col-md-10">
			<?php echo form_submit( array( 'id' => 'submit_login', 'value' => 'Login', 
			'class' => 'btn btn-primary btn-cons pull-right' ) ); ?>
		</div>
        </div>
      </form>
    </div>