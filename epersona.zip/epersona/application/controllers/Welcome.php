<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		
		$header_data = array();
		$header_data['title'] = "Home";
		
		$this->load->view('header', $header_data);
		$this->load->view('signup');
		$this->load->view('footer');
		
	}
}
