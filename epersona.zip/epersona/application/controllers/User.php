<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function signup()
	{
		$header_data = array();
		$header_data['title'] = "Signup";
		
		$this->load->view('header', $header_data);
		$this->load->view('signup');
		$this->load->view('footer');
		
	}
	
	public function login()
	{
		$header_data			= array();
		$header_data['title']	= "Login";
		
		$this->load->view('header', $header_data);
		$this->load->view('login');
		$this->load->view('footer');
		
	}
	
	public function dashboard()
	{
		if( ! $this->session->has_userdata('login_key') ){
			redirect( base_url(), 'refresh' );
		}
		
		$header_data			= array();
		$header_data['title']	= "Dashboard";
		
		$this->load->view('header', $header_data);
		$this->load->view('dashboard');
		$this->load->view('footer');
		
	}
	
	public function login_process()
	{
		$this->load->model( 'User_model', '', TRUE );
		
		if ( $this->User_model->check_email_existing_user() === true ) {
			
			$user = $this->User_model->login_user();
			if( $user !== false ){
				redirect( base_url('/user/dashboard'), 'refresh' );
			}else{
				
			}
		
		}
		else {
			echo "asdfds";
		}
		
	}
	
	public function process_signup()
	{
		if( ! isset( $_POST['checkbox1'] ) ){
			$this->session->set_flashdata( 'signup_error', 'You must agree to terms and conditions' );
			redirect( '/user/signup', 'refresh' );
		}else if( isset( $_POST['password'] ) && isset( $_POST['confirm_password'] ) &&
			! empty( $_POST['password'] ) && ! empty( $_POST['confirm_password'] ) ){
			if( $_POST['password'] != $_POST['confirm_password'] ){
				$this->session->set_flashdata( 'signup_error', 'Passwords do not match' );
				redirect( '/user/signup', 'refresh' );
			}
		}
		
		$this->load->model('User_model', '', TRUE);
		
		if ( $this->User_model->check_email_existing_user() === false ) {
		
			$this->User_model->add_user();
		
		}
		else {
			
		}
		
	}
	
	public function change_password( $user_id, $random_key )
	{
		$header_data					= array();
		$header_data['title']			= "Change Password";
		echo $header_data['user_id']	= $user_id;
		$header_data['reset_key']		= $random_key;
		
		$this->load->model( 'User_model', '', TRUE );
		
		if( $this->User_model->check_reset_password_link( $user_id, $random_key ) === true ){
			$this->load->view('header', $header_data);
			$this->load->view('change_password');
			$this->load->view('footer');
		}else{
			redirect( '/user/password_reset', 'refresh' );
		}
		
	}
	
	
	public function update_password()
	{
		$this->load->model('User_model', '', TRUE);
		
		$user_id			= $this->input->post('user_id');
		$reset_key			= $this->input->post('reset_key');
		$password			= $this->input->post('password');
		$confirm_password	= $this->input->post('confirm_password');
		if( ! empty( $password ) && $password != $confirm_password ){
			redirect( '/user/change_password/'.$user_id.'/'.$reset_key, 'refresh' );
			$this->session->set_flashdata( 'reset_password_error', 'Passwords do not match' );
		}else{
			if( $this->User_model->update_password( $user_id, $password ) ){
				echo "Password updated";
			}
		}
		//print_r( $this->User_model->send_reset_password_email() );
	}
	
	
	
	public function password_reset()
	{
		$header_data			= array();
		$header_data['title']	= "Reset Password";
		
		$this->load->view('header', $header_data);
		$this->load->view('reset');
		$this->load->view('footer');
	}
	
	public function send_reset_password_email()
	{
		
		$this->load->model('User_model', '', TRUE);
		
		print_r( $this->User_model->send_reset_password_email() );
	}
}
